from django.apps import AppConfig


class FeaturedSellerConfig(AppConfig):
    name = 'featured_seller'
