from django.apps import AppConfig


class LargeBannerConfig(AppConfig):
    name = 'large_banner'
