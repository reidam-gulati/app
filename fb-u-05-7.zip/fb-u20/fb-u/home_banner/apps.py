from django.apps import AppConfig


class HomeBannerConfig(AppConfig):
    name = 'home_banner'
