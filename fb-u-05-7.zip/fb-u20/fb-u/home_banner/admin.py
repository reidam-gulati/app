from django.contrib import admin
from .models import HomeBanner
# Register your models here.
admin.site.register(HomeBanner)